package com.example.fraudbot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.widget.Toast

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val body = sms.displayMessageBody

                // Automatic logic: detects fraud without typing
                val isFraud = body.contains("otp", true) ||
                        body.contains("bank", true) ||
                        body.contains("password", true)

                if (isFraud) {
                    // This shows a warning immediately on your screen
                    Toast.makeText(context, "🚨 SECURITY ALERT: Potential Fraud SMS detected!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
