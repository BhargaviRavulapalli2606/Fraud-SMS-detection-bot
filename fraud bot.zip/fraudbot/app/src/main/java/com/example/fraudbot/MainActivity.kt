package com.example.fraudbot

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.QUEUE_FLUSH
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tts: TextToSpeech
    private lateinit var chatDisplay: TextView
    private lateinit var userInput: EditText
    private lateinit var sendButton: Button
    private lateinit var languageSpinner: Spinner

    private val languageMap = mapOf(
        "Hindi" to TranslateLanguage.HINDI,
        "Bengali" to TranslateLanguage.BENGALI,
        "Telugu" to TranslateLanguage.TELUGU,
        "Marathi" to TranslateLanguage.MARATHI,
        "Tamil" to TranslateLanguage.TAMIL,
        "Gujarati" to TranslateLanguage.GUJARATI,
        "Kannada" to TranslateLanguage.KANNADA
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Request SMS Permissions immediately
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 1)
        }

        chatDisplay = findViewById(R.id.chatDisplay)
        userInput = findViewById(R.id.userInput)
        sendButton = findViewById(R.id.sendButton)
        languageSpinner = findViewById(R.id.languageSpinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languageMap.keys.toList())
        languageSpinner.adapter = adapter

        tts = TextToSpeech(this) { status ->
            if (status != TextToSpeech.ERROR) {
                // FIXED: Rectified the Locale warning
                tts.language = Locale.forLanguageTag("hi-IN")
            }
        }

        sendButton.setOnClickListener {
            val message = userInput.text.toString().trim()
            if (message.isNotEmpty()) {
                chatDisplay.append("\n\nUser: $message")
                val selectedLang = languageSpinner.selectedItem.toString()
                val targetCode = languageMap[selectedLang] ?: TranslateLanguage.HINDI
                processAiLogic(message, targetCode)
                userInput.text.clear()
            }
        }
    }

    private fun processAiLogic(userText: String, targetLang: String) {
        val isFraud = userText.contains("otp", true) ||
                userText.contains("password", true) ||
                userText.contains("bank", true)

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)
        chatDisplay.append("\nBot: Analyzing...")

        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translator.translate(userText)
                    .addOnSuccessListener { translatedText ->
                        val prefix = if (isFraud) "⚠️ FRAUD ALERT: " else "✅ SAFE: "
                        val finalMsg = "$prefix$translatedText"
                        chatDisplay.append("\nBot: $finalMsg")
                        speakText(finalMsg)
                    }
            }
    }

    private fun speakText(text: String) {
        tts.speak(text, QUEUE_FLUSH, null, null)
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}