package com.example.fraudbot

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.speech.tts.TextToSpeech
import java.util.Locale

class FloatingBotService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private lateinit var floatingButton: Button
    private lateinit var tts: TextToSpeech

    override fun onServiceConnected() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { tts.language = Locale.forLanguageTag("hi-IN") }

        floatingButton = Button(this).apply {
            text = "🔊 Read Screen"
            setBackgroundColor(android.graphics.Color.RED)
            setTextColor(android.graphics.Color.WHITE)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 100
        }

        floatingButton.setOnClickListener {
            val rootNode = rootInActiveWindow
            if (rootNode != null) {
                readNode(rootNode)
            }
        }

        windowManager.addView(floatingButton, params)
    }

    private fun readNode(node: AccessibilityNodeInfo) {
        val content = node.text?.toString() ?: ""
        if (content.isNotEmpty()) {
            val prefix = if (content.lowercase().contains("otp")) "Warning: " else ""
            tts.speak("$prefix$content", TextToSpeech.QUEUE_FLUSH, null, null)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { readNode(it) }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() {}
}