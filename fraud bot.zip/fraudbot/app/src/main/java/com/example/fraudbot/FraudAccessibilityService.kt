package com.example.fraudbot

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class FraudAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val rootNode = rootInActiveWindow ?: return
        checkNodes(rootNode)
    }

    private fun checkNodes(node: AccessibilityNodeInfo) {
        val content = node.text?.toString()?.lowercase() ?: ""
        if (content.contains("otp") || content.contains("bank") || content.contains("blocked")) {
            Toast.makeText(this, "⚠️ FRAUD DETECTED IN MESSAGE!", Toast.LENGTH_LONG).show()
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { checkNodes(it) }
        }
    }

    override fun onInterrupt() {}
}